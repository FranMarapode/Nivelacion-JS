// Ejercicio 1
    let nombre = prompt("Ingrese su nombre");
    console.log("Hola " + nombre + ", saludos!!")

//Ejercicio 2

    let num1 = parseFloat(prompt("Ingrese el primer número"));
    let num2 = parseFloat(prompt("Ingrese el segundo número"));
    console.log(num1 + num2)
    console.log(num1 - num2)
    console.log(num1 * num2)
    console.log(num1 / num2)

//Ejercicio 3

    num1 = parseFloat(prompt("Ingrese un número"));
    if (num1 % 2 == 0) {
        console.log("El numero es par")
    }
    else console.log("El numero es impar")
   
//Ejercicio 4

    let palabra = prompt("Ingrese una palabra.")
    console.log(palabra.length)
    
//Ejercicio 5

    let Frase = prompt("Ingrese una frase.")
    num1 = parseInt(prompt("Ingrese un número."))
    for (let i = 1; i <= num1; i++) {
       console.log(i + ":" + Frase)   
    }

//Ejercicio 6

num1 = parseInt(prompt("Ingrese un número"));
for (let i = 1; i <= 10; i++) {
    console.log(num1 * i)
}

//Ejercicio 7

const Rand = () => Math.floor(Math.random() * (11));
let numeroRandom = Rand()
num1 = -1
while (numeroRandom != num1) {

    num1 = parseInt(prompt("Intenta adivinar un numero entre 1 y 10."))
    if (num1 > numeroRandom) {
        console.log("El numero es menor")
    }
    if (num1 < numeroRandom) {
        console.log("El numero es mayor")
    }
}

//Ejercicio 8
let contador = 0;
palabra = prompt("Ingrese una palabra.")
for (let letra of palabra) {
let vocales = "aeiouáéíóúAEIOUÁÉÍÓÚ";
    if (vocales.includes(letra)) {
        contador++;
    }
    
}
console.log("Tiene " + contador + " vocales.")

//Ejercicio 9

palabra = prompt("Ingrese una palabra.")
let palabraInvertida = palabra.split("").reverse().join("");
console.log(palabraInvertida)

//Ejercicio 10

palabra = prompt("Ingrese una palabra.")
palabraInvertida = palabra.split("").reverse().join("");
if (palabra == palabraInvertida) {
    console.log("La palabra es un palíndromo.")
}
if (palabra != palabraInvertida) {
    console.log("La palabra no es un palindromo.")
}

